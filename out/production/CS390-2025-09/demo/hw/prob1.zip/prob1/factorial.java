package prob1;

import java.util.Scanner;

public class factorial {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.print("Type a Number: ");
		long n = in.nextInt();
		System.out.println("Factorial = " + fact(n));
	}
	/* Task: Write a recursive solution to find the Factorial of the given input.
	         Your code must properly address the Base and recursive case.
	         Your code does not give null or stackoverflow exceptions.
	         Do the necessary validation to avoid runtime errors
	*/
	static long fact(long num) {
		// Write your implementation

	  return 0;
	}

}
