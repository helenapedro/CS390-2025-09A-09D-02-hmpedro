package hwsort.taska;

import java.time.LocalDate;
import java.util.Date;

public class Professor extends DeptEmployee {

	public Professor(String name, double salary, LocalDate hireDate){
		super(name,salary,hireDate);
	}
}
