package lesson5;

public class ChildAbstract extends AbstractParent{
    @Override
    void test() {

    }

    @Override
    int add(int a, int b) {
        return a+b;
    }
}
