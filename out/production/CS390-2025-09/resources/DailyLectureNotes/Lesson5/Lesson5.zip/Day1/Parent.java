package lesson5;

public class Parent {
  /*public   Parent(){
        System.out.println("Parent Constructor");
    }*/
    public Parent(int x){
        System.out.println("Parameter Constructor");
    }
}
