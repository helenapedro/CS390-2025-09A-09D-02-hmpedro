package lesson6;

public class TestLocalClass {
    public static void main(String[] args) {
        LocalClass ob = new LocalClass();
        ob.myMethod(12);
    }
}
