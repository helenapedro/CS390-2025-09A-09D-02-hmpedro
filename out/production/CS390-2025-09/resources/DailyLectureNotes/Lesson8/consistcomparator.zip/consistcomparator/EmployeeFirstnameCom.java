package lesson8;

public class EmployeeFirstnameCom implements Comparable<Employee>{
    @Override
    public int compareTo(Employee o) {
        return 0;
    }
}
