package lesson12.inclassexercise;

public class StackException extends Exception {
	public StackException() {
		super();
	}
	public StackException(Throwable t) {
		super(t);
	}
	public StackException(String msg) {
		super(msg);
	}
}
