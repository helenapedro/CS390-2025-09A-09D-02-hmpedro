package TestPack;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class BankAccountTest {
    private BankAccount account;

    @BeforeEach
    void setUp() {
        System.out.println("Setting up a new BankAccount with $100 balance.");
        account = new BankAccount(100); // Initialize before each test
    }

    @AfterEach
    void tearDown() {
        System.out.println("Test completed. Cleaning up...");
    }

    @Test
    void testDeposit() {
        account.deposit(50);
        assertEquals(150, account.getBalance(), "Balance should be 150 after deposit of 50");
    }
    @Test
    void testWithdraw() {
        account.withdraw(40);
        // Before executing this test-case balance changed to 100
        assertEquals(60, account.getBalance(), "Balance should be 60 after withdrawal of 40");
    }
      // Check this part after Lesson-12 Exception Handling
}