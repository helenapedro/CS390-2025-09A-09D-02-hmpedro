package TestPack;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MyClassTest {
@Test
    public void test1(){
    int act = MyClass.fact(3);
    int exp = 6;
    assertEquals(exp,act);
}
@Test
    public void test2(){
    int act = MyClass.Sum(4);
    int exp = 10;
    assertEquals(exp,act);
}
}