package lesson5.day2;

public class TestEmployee {
    public static void main(String[] args) {
        Employee ob = new Employee();
        ob.setName("Renuka");
        Class c = ob.getClass();

    }
}
