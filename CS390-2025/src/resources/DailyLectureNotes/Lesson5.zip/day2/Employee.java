package lesson5.day2;

import java.lang.reflect.InvocationTargetException;

public class Employee {
	public static  final int ab = 0;
	private String name;
	private int salary;
	public Employee() {

	}
	public String getName() {
		return name;
	}
	public int getSalary() {
		return salary;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	public void setSalary(int sal) {
		this.salary = sal;
	}
	
	@Override
	public String toString() {
		return name + ": " + salary;
	}
}


