package lesson5.day2.interfaces;

public class MyClass implements MyInterface, Calculator {
    @Override
    public void test() {
        System.out.println("Test Message");
    }

    @Override
    public int sum(int a, int b) {
        return a+b;
    }

    @Override
    public String concat(String a, String b) {
        return a + " " + b ;
    }
}
