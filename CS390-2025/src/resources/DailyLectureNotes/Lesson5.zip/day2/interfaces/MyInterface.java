package lesson5.day2.interfaces;
// PRE JDK 8
// Not a Functional Interface
//@FunctionalInterface
public interface MyInterface {
    // Can I include fields inside the Interface, Yes. All fields are public static final
    public static final int CONST=100;
    void test(); // It is equivalent to public abstract void test()
    public abstract int sum(int a, int b);

}
