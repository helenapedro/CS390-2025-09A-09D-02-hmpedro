package lesson5.day2.interfaces;

public class MyTestClass {
    public static void main(String[] args) {
        // You cannot create object for interface using new
      //  MyInterface ob = new MyInterface();
        // You can declare as a type of Interface, runtime object is Sub type
        MyInterface ob1 = new MyClass();
        ob1.test();
        System.out.println("Sum = " + ob1.sum(10,20));
        System.out.println(MyInterface.CONST);
       // MyInterface.CONST += 20; // You cannot modify
        Calculator cal = new MyClass();
        System.out.println(cal.concat("Renuka", "Mohanraj"));
        MyClass ob2 = new MyClass(); // You can access all the behaviours



    }
}
