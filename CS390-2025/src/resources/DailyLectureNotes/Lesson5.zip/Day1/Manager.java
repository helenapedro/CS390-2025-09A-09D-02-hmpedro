package lesson5;
// I want to Inherit Employee, Manager is a Employee
// use the keyword extends Parent class name in your child class
public class Manager  extends Employee{
	// You can include additional attributes, behavior in your child class
	private double bonus;
	public Manager(String name, double salary, int year, int month, int day) {
		// More reading JDK 22 before super() : https://openjdk.org/jeps/447
		super(name,salary,year,month,day); // JDK 22, it may not be first line to perform input validation
		bonus = 0.0;
	}
	public Manager(){
		super();
	}
    public void	 setBonus(double b) {
		bonus = b;
	}
	/* Overriding - You can customize the parent behavior in your child class
	 * Dynamic binding, late binding
	 * You have to follow the same signature from the Parent
	 * override the behaviour of getSalary()
	 * @Override - Annotation is for readability as well as compiler verification
	 */
	@Override
	public double getSalary(){
		// salary is a private field, to call parent method use super.parent method()
		return  super.getSalary() + bonus;
	}
  }
