package lesson5;

public class Child extends Parent{
   public Child(int a, int b){
     //  System.out.println(a);
       super(b);
        System.out.println("Child Class Constructor");
    }
}
