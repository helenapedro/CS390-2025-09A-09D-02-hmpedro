package lesson5;

import java.util.Date;

public class EmployeeTest {
	public static void main(String[] args) {
		//Employee ob1 = new Parent(10);
		Employee ob5 = new Manager();
	//	((Manager) ob5).setBonus(4500);
		Employee e1 = new Employee(); // Both left and Right is type of Employee
		Manager m = new Manager();
		// e2 is a early binded type with Employee at compile time
		//Employee e2 = new Manager(); // Manager is a Employee
		//	((Manager) e2).setBonus(5000); // Casting

		// The above line is similar to below code
		byte b = 10;
		int b1 = b;
		// when you e1.methods() or e2.methods() - can see only Employee methods
		// e3 is a Manager type both compile type and Run time type
		Manager e3 = new Manager();
		// e3.methods(), can see all parent and child specific methods

		//Array of an Employee collection
		Employee[] staff = new Employee[3];
		Manager boss = new Manager("Boss Guy", 80000, 2009, 12, 15);
		boss.setBonus(5000);
		staff[0] = boss;
		staff[1] = new Employee("Jimbo", 50000, 2012, 10, 1);
		staff[2] = new Employee("Tommy", 40000, 2013, 3, 15);

		// Polymorphism, want to print and sum of salaries
		double sum = 0.0;
		for(Employee e:staff) {
			// oth index call Manager getSalary, other two index gerSalary from Employee
			sum = sum + e.getSalary();
			System.out.println(e.getName() + " " + e.getSalary());
			System.out.println(e instanceof Manager);
		}
		String x = "Java";
		System.out.println(x instanceof Object);
		System.out.println("Total Employee Salary");
		Employee e4 = new Employee("Jimbo", 50000, 2012, 10, 1);
		Employee ob = new Manager();
		print(boss);
	//	print(ob);

	}
	public static void print(Employee e) {
		System.out.println(e.getName());
	}
}
