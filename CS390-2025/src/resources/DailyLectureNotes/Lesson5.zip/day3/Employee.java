package lesson5.day3;

import java.util.Objects;

public class Employee {
	private String name;
	private int salary;

	public Employee(String name, int salary) {
		this.name = name;
		this.salary = salary;
	}
	public String getName() {
		return name;
	}
	public int getSalary() {
		return salary;
	}

	public void setName(String name) {
		this.name = name;
	}
	public void setSalary(int sal) {
		this.salary = sal;
	}
	@Override
	public String toString() {
		return name + ": " + salary;
	}
	@Override
	public boolean equals(Object ob){
		//1. Check null
		if(ob==null) return false;
		//2. If I compare the same object
		if(this==ob) return true;
		//3. Need to check the ob type
		// To check either instanceof or getClass()
		if(ob.getClass()!=this.getClass()) return false;
		//if(!(ob instanceof Employee)) return false;
		// Convert Object to Employee before comparing
				Employee e = (Employee)ob;
		/*if(this.name.equals(e.name) && this.salary==e.salary)
			return true;
		else
			return false;*/
		//boolean res = this.name.equals(e.name) && this.salary==e.salary;
		boolean res = Objects.equals(this.name,e.name) && this.salary==e.salary;
		return res;
	}
}


